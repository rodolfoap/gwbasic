#Translated by Mateusz Viste "Fox" / the.killer@wp.pl
#Polish letters encoded in the MAZOVIA standard
#Homepage: http://www.the.killer.webpark.pl/en/fdos_pl.htm
#
2.0:Niepoprawny parametr\r\n
0.0:    SORT [/R] [/+num] [/?]\r\n
0.1:    /R    Odwraca kolejno��\r\n
0.2:    /N    W��cza obs�ug� NLS\r\n
0.3:    /+num Uruchamia sortowanie kolumn num, bazowane na 1\r\n
0.4:    /?    Pomoc\r\n
2.1:B��d w odczycie tablicy NLS\r\n
2.2:NLS wymaga DOS w wersji 3.3 lub nowszej!\r\n
2.3:SORT: Nie mo�na otworzy� pliku 
2.4: do odczytu\n
2.5:SORT: Zbyt ma�o pami�ci\r\n
2.6:SORT: Liczba rekord�w przekroczy�a obs�ugiwane maksimum\r\n
